﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.input = New System.Windows.Forms.TextBox()
        Me.btn_e = New System.Windows.Forms.Button()
        Me.btn_r = New System.Windows.Forms.Button()
        Me.btn_x = New System.Windows.Forms.Button()
        Me.T1 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_c = New System.Windows.Forms.Button()
        Me.T2 = New System.Windows.Forms.Timer(Me.components)
        Me.T3 = New System.Windows.Forms.Timer(Me.components)
        Me.T4 = New System.Windows.Forms.Timer(Me.components)
        Me.T5 = New System.Windows.Forms.Timer(Me.components)
        Me.T6 = New System.Windows.Forms.Timer(Me.components)
        Me.T7 = New System.Windows.Forms.Timer(Me.components)
        Me.T8 = New System.Windows.Forms.Timer(Me.components)
        Me.T9 = New System.Windows.Forms.Timer(Me.components)
        Me.T10 = New System.Windows.Forms.Timer(Me.components)
        Me.T11 = New System.Windows.Forms.Timer(Me.components)
        Me.A = New System.Windows.Forms.Label()
        Me.A1 = New System.Windows.Forms.Label()
        Me.A2 = New System.Windows.Forms.Label()
        Me.A3 = New System.Windows.Forms.Label()
        Me.A4 = New System.Windows.Forms.Label()
        Me.B = New System.Windows.Forms.Label()
        Me.B1 = New System.Windows.Forms.Label()
        Me.B2 = New System.Windows.Forms.Label()
        Me.B3 = New System.Windows.Forms.Label()
        Me.B4 = New System.Windows.Forms.Label()
        Me.C = New System.Windows.Forms.Label()
        Me.C4 = New System.Windows.Forms.Label()
        Me.C3 = New System.Windows.Forms.Label()
        Me.C2 = New System.Windows.Forms.Label()
        Me.C1 = New System.Windows.Forms.Label()
        Me.D = New System.Windows.Forms.Label()
        Me.D4 = New System.Windows.Forms.Label()
        Me.D3 = New System.Windows.Forms.Label()
        Me.D2 = New System.Windows.Forms.Label()
        Me.D1 = New System.Windows.Forms.Label()
        Me.EE = New System.Windows.Forms.Label()
        Me.E4 = New System.Windows.Forms.Label()
        Me.E3 = New System.Windows.Forms.Label()
        Me.E2 = New System.Windows.Forms.Label()
        Me.E1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'input
        '
        Me.input.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.input.Location = New System.Drawing.Point(50, 54)
        Me.input.Name = "input"
        Me.input.Size = New System.Drawing.Size(183, 38)
        Me.input.TabIndex = 7
        '
        'btn_e
        '
        Me.btn_e.BackColor = System.Drawing.Color.Green
        Me.btn_e.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_e.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_e.Location = New System.Drawing.Point(50, 124)
        Me.btn_e.Name = "btn_e"
        Me.btn_e.Size = New System.Drawing.Size(89, 29)
        Me.btn_e.TabIndex = 8
        Me.btn_e.Text = "ENTER"
        Me.btn_e.UseVisualStyleBackColor = False
        '
        'btn_r
        '
        Me.btn_r.BackColor = System.Drawing.Color.Coral
        Me.btn_r.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_r.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_r.Location = New System.Drawing.Point(50, 179)
        Me.btn_r.Name = "btn_r"
        Me.btn_r.Size = New System.Drawing.Size(89, 29)
        Me.btn_r.TabIndex = 16
        Me.btn_r.Text = "RETRY"
        Me.btn_r.UseVisualStyleBackColor = False
        Me.btn_r.Visible = False
        '
        'btn_x
        '
        Me.btn_x.BackColor = System.Drawing.Color.Red
        Me.btn_x.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_x.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_x.Location = New System.Drawing.Point(50, 234)
        Me.btn_x.Name = "btn_x"
        Me.btn_x.Size = New System.Drawing.Size(89, 29)
        Me.btn_x.TabIndex = 17
        Me.btn_x.Text = "EXIT"
        Me.btn_x.UseVisualStyleBackColor = False
        Me.btn_x.Visible = False
        '
        'T1
        '
        Me.T1.Interval = 1000
        '
        'btn_c
        '
        Me.btn_c.BackColor = System.Drawing.Color.Gold
        Me.btn_c.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_c.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_c.Location = New System.Drawing.Point(145, 124)
        Me.btn_c.Name = "btn_c"
        Me.btn_c.Size = New System.Drawing.Size(88, 29)
        Me.btn_c.TabIndex = 18
        Me.btn_c.Text = "COUNT"
        Me.btn_c.UseVisualStyleBackColor = False
        '
        'T2
        '
        Me.T2.Interval = 1000
        '
        'T3
        '
        Me.T3.Interval = 1000
        '
        'T4
        '
        Me.T4.Interval = 1000
        '
        'T5
        '
        Me.T5.Interval = 1000
        '
        'T6
        '
        Me.T6.Interval = 1000
        '
        'T7
        '
        Me.T7.Interval = 1000
        '
        'T8
        '
        Me.T8.Interval = 1000
        '
        'T9
        '
        Me.T9.Interval = 1000
        '
        'T10
        '
        Me.T10.Interval = 1000
        '
        'T11
        '
        Me.T11.Interval = 1000
        '
        'A
        '
        Me.A.BackColor = System.Drawing.Color.Maroon
        Me.A.Location = New System.Drawing.Point(343, 54)
        Me.A.Name = "A"
        Me.A.Padding = New System.Windows.Forms.Padding(2)
        Me.A.Size = New System.Drawing.Size(20, 20)
        Me.A.TabIndex = 20
        '
        'A1
        '
        Me.A1.BackColor = System.Drawing.Color.Maroon
        Me.A1.Location = New System.Drawing.Point(383, 54)
        Me.A1.Name = "A1"
        Me.A1.Padding = New System.Windows.Forms.Padding(2)
        Me.A1.Size = New System.Drawing.Size(20, 20)
        Me.A1.TabIndex = 21
        '
        'A2
        '
        Me.A2.BackColor = System.Drawing.Color.Maroon
        Me.A2.Location = New System.Drawing.Point(424, 54)
        Me.A2.Name = "A2"
        Me.A2.Padding = New System.Windows.Forms.Padding(2)
        Me.A2.Size = New System.Drawing.Size(20, 20)
        Me.A2.TabIndex = 22
        '
        'A3
        '
        Me.A3.BackColor = System.Drawing.Color.Maroon
        Me.A3.Location = New System.Drawing.Point(466, 54)
        Me.A3.Name = "A3"
        Me.A3.Padding = New System.Windows.Forms.Padding(2)
        Me.A3.Size = New System.Drawing.Size(20, 20)
        Me.A3.TabIndex = 23
        '
        'A4
        '
        Me.A4.BackColor = System.Drawing.Color.Maroon
        Me.A4.Location = New System.Drawing.Point(507, 54)
        Me.A4.Name = "A4"
        Me.A4.Padding = New System.Windows.Forms.Padding(2)
        Me.A4.Size = New System.Drawing.Size(20, 20)
        Me.A4.TabIndex = 24
        '
        'B
        '
        Me.B.BackColor = System.Drawing.Color.Maroon
        Me.B.Location = New System.Drawing.Point(343, 104)
        Me.B.Name = "B"
        Me.B.Padding = New System.Windows.Forms.Padding(2)
        Me.B.Size = New System.Drawing.Size(20, 20)
        Me.B.TabIndex = 25
        '
        'B1
        '
        Me.B1.BackColor = System.Drawing.Color.Maroon
        Me.B1.Location = New System.Drawing.Point(383, 104)
        Me.B1.Name = "B1"
        Me.B1.Padding = New System.Windows.Forms.Padding(2)
        Me.B1.Size = New System.Drawing.Size(20, 20)
        Me.B1.TabIndex = 26
        '
        'B2
        '
        Me.B2.BackColor = System.Drawing.Color.Maroon
        Me.B2.Location = New System.Drawing.Point(424, 104)
        Me.B2.Name = "B2"
        Me.B2.Padding = New System.Windows.Forms.Padding(2)
        Me.B2.Size = New System.Drawing.Size(20, 20)
        Me.B2.TabIndex = 27
        '
        'B3
        '
        Me.B3.BackColor = System.Drawing.Color.Maroon
        Me.B3.Location = New System.Drawing.Point(466, 104)
        Me.B3.Name = "B3"
        Me.B3.Padding = New System.Windows.Forms.Padding(2)
        Me.B3.Size = New System.Drawing.Size(20, 20)
        Me.B3.TabIndex = 28
        '
        'B4
        '
        Me.B4.BackColor = System.Drawing.Color.Maroon
        Me.B4.Location = New System.Drawing.Point(507, 104)
        Me.B4.Name = "B4"
        Me.B4.Padding = New System.Windows.Forms.Padding(2)
        Me.B4.Size = New System.Drawing.Size(20, 20)
        Me.B4.TabIndex = 29
        '
        'C
        '
        Me.C.BackColor = System.Drawing.Color.Maroon
        Me.C.Location = New System.Drawing.Point(343, 152)
        Me.C.Name = "C"
        Me.C.Padding = New System.Windows.Forms.Padding(2)
        Me.C.Size = New System.Drawing.Size(20, 20)
        Me.C.TabIndex = 30
        '
        'C4
        '
        Me.C4.BackColor = System.Drawing.Color.Maroon
        Me.C4.Location = New System.Drawing.Point(507, 152)
        Me.C4.Name = "C4"
        Me.C4.Padding = New System.Windows.Forms.Padding(2)
        Me.C4.Size = New System.Drawing.Size(20, 20)
        Me.C4.TabIndex = 31
        '
        'C3
        '
        Me.C3.BackColor = System.Drawing.Color.Maroon
        Me.C3.Location = New System.Drawing.Point(466, 152)
        Me.C3.Name = "C3"
        Me.C3.Padding = New System.Windows.Forms.Padding(2)
        Me.C3.Size = New System.Drawing.Size(20, 20)
        Me.C3.TabIndex = 32
        '
        'C2
        '
        Me.C2.BackColor = System.Drawing.Color.Maroon
        Me.C2.Location = New System.Drawing.Point(424, 152)
        Me.C2.Name = "C2"
        Me.C2.Padding = New System.Windows.Forms.Padding(2)
        Me.C2.Size = New System.Drawing.Size(20, 20)
        Me.C2.TabIndex = 33
        '
        'C1
        '
        Me.C1.BackColor = System.Drawing.Color.Maroon
        Me.C1.Location = New System.Drawing.Point(383, 152)
        Me.C1.Name = "C1"
        Me.C1.Padding = New System.Windows.Forms.Padding(2)
        Me.C1.Size = New System.Drawing.Size(20, 20)
        Me.C1.TabIndex = 34
        '
        'D
        '
        Me.D.BackColor = System.Drawing.Color.Maroon
        Me.D.Location = New System.Drawing.Point(343, 198)
        Me.D.Name = "D"
        Me.D.Padding = New System.Windows.Forms.Padding(2)
        Me.D.Size = New System.Drawing.Size(20, 20)
        Me.D.TabIndex = 30
        '
        'D4
        '
        Me.D4.BackColor = System.Drawing.Color.Maroon
        Me.D4.Location = New System.Drawing.Point(507, 198)
        Me.D4.Name = "D4"
        Me.D4.Padding = New System.Windows.Forms.Padding(2)
        Me.D4.Size = New System.Drawing.Size(20, 20)
        Me.D4.TabIndex = 31
        '
        'D3
        '
        Me.D3.BackColor = System.Drawing.Color.Maroon
        Me.D3.Location = New System.Drawing.Point(466, 198)
        Me.D3.Name = "D3"
        Me.D3.Padding = New System.Windows.Forms.Padding(2)
        Me.D3.Size = New System.Drawing.Size(20, 20)
        Me.D3.TabIndex = 32
        '
        'D2
        '
        Me.D2.BackColor = System.Drawing.Color.Maroon
        Me.D2.Location = New System.Drawing.Point(424, 198)
        Me.D2.Name = "D2"
        Me.D2.Padding = New System.Windows.Forms.Padding(2)
        Me.D2.Size = New System.Drawing.Size(20, 20)
        Me.D2.TabIndex = 33
        '
        'D1
        '
        Me.D1.BackColor = System.Drawing.Color.Maroon
        Me.D1.Location = New System.Drawing.Point(383, 198)
        Me.D1.Name = "D1"
        Me.D1.Padding = New System.Windows.Forms.Padding(2)
        Me.D1.Size = New System.Drawing.Size(20, 20)
        Me.D1.TabIndex = 34
        '
        'EE
        '
        Me.EE.BackColor = System.Drawing.Color.Maroon
        Me.EE.Location = New System.Drawing.Point(343, 243)
        Me.EE.Name = "EE"
        Me.EE.Padding = New System.Windows.Forms.Padding(2)
        Me.EE.Size = New System.Drawing.Size(20, 20)
        Me.EE.TabIndex = 30
        '
        'E4
        '
        Me.E4.BackColor = System.Drawing.Color.Maroon
        Me.E4.Location = New System.Drawing.Point(507, 243)
        Me.E4.Name = "E4"
        Me.E4.Padding = New System.Windows.Forms.Padding(2)
        Me.E4.Size = New System.Drawing.Size(20, 20)
        Me.E4.TabIndex = 31
        '
        'E3
        '
        Me.E3.BackColor = System.Drawing.Color.Maroon
        Me.E3.Location = New System.Drawing.Point(466, 243)
        Me.E3.Name = "E3"
        Me.E3.Padding = New System.Windows.Forms.Padding(2)
        Me.E3.Size = New System.Drawing.Size(20, 20)
        Me.E3.TabIndex = 32
        '
        'E2
        '
        Me.E2.BackColor = System.Drawing.Color.Maroon
        Me.E2.Location = New System.Drawing.Point(424, 243)
        Me.E2.Name = "E2"
        Me.E2.Padding = New System.Windows.Forms.Padding(2)
        Me.E2.Size = New System.Drawing.Size(20, 20)
        Me.E2.TabIndex = 33
        '
        'E1
        '
        Me.E1.BackColor = System.Drawing.Color.Maroon
        Me.E1.Location = New System.Drawing.Point(383, 243)
        Me.E1.Name = "E1"
        Me.E1.Padding = New System.Windows.Forms.Padding(2)
        Me.E1.Size = New System.Drawing.Size(20, 20)
        Me.E1.TabIndex = 34
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(343, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(2)
        Me.Label1.Size = New System.Drawing.Size(20, 20)
        Me.Label1.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label2.Location = New System.Drawing.Point(383, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Padding = New System.Windows.Forms.Padding(2)
        Me.Label2.Size = New System.Drawing.Size(20, 20)
        Me.Label2.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label3.Location = New System.Drawing.Point(424, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Padding = New System.Windows.Forms.Padding(2)
        Me.Label3.Size = New System.Drawing.Size(20, 20)
        Me.Label3.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label4.Location = New System.Drawing.Point(466, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Padding = New System.Windows.Forms.Padding(2)
        Me.Label4.Size = New System.Drawing.Size(20, 20)
        Me.Label4.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label5.Location = New System.Drawing.Point(507, 53)
        Me.Label5.Name = "Label5"
        Me.Label5.Padding = New System.Windows.Forms.Padding(2)
        Me.Label5.Size = New System.Drawing.Size(20, 20)
        Me.Label5.TabIndex = 24
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label6.Location = New System.Drawing.Point(343, 103)
        Me.Label6.Name = "Label6"
        Me.Label6.Padding = New System.Windows.Forms.Padding(2)
        Me.Label6.Size = New System.Drawing.Size(20, 20)
        Me.Label6.TabIndex = 25
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label7.Location = New System.Drawing.Point(383, 103)
        Me.Label7.Name = "Label7"
        Me.Label7.Padding = New System.Windows.Forms.Padding(2)
        Me.Label7.Size = New System.Drawing.Size(20, 20)
        Me.Label7.TabIndex = 26
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label8.Location = New System.Drawing.Point(424, 103)
        Me.Label8.Name = "Label8"
        Me.Label8.Padding = New System.Windows.Forms.Padding(2)
        Me.Label8.Size = New System.Drawing.Size(20, 20)
        Me.Label8.TabIndex = 27
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label9.Location = New System.Drawing.Point(466, 103)
        Me.Label9.Name = "Label9"
        Me.Label9.Padding = New System.Windows.Forms.Padding(2)
        Me.Label9.Size = New System.Drawing.Size(20, 20)
        Me.Label9.TabIndex = 28
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label10.Location = New System.Drawing.Point(507, 103)
        Me.Label10.Name = "Label10"
        Me.Label10.Padding = New System.Windows.Forms.Padding(2)
        Me.Label10.Size = New System.Drawing.Size(20, 20)
        Me.Label10.TabIndex = 29
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label11.Location = New System.Drawing.Point(343, 151)
        Me.Label11.Name = "Label11"
        Me.Label11.Padding = New System.Windows.Forms.Padding(2)
        Me.Label11.Size = New System.Drawing.Size(20, 20)
        Me.Label11.TabIndex = 30
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label12.Location = New System.Drawing.Point(343, 197)
        Me.Label12.Name = "Label12"
        Me.Label12.Padding = New System.Windows.Forms.Padding(2)
        Me.Label12.Size = New System.Drawing.Size(20, 20)
        Me.Label12.TabIndex = 30
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label13.Location = New System.Drawing.Point(343, 242)
        Me.Label13.Name = "Label13"
        Me.Label13.Padding = New System.Windows.Forms.Padding(2)
        Me.Label13.Size = New System.Drawing.Size(20, 20)
        Me.Label13.TabIndex = 30
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label14.Location = New System.Drawing.Point(507, 151)
        Me.Label14.Name = "Label14"
        Me.Label14.Padding = New System.Windows.Forms.Padding(2)
        Me.Label14.Size = New System.Drawing.Size(20, 20)
        Me.Label14.TabIndex = 31
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label15.Location = New System.Drawing.Point(507, 197)
        Me.Label15.Name = "Label15"
        Me.Label15.Padding = New System.Windows.Forms.Padding(2)
        Me.Label15.Size = New System.Drawing.Size(20, 20)
        Me.Label15.TabIndex = 31
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label16.Location = New System.Drawing.Point(507, 242)
        Me.Label16.Name = "Label16"
        Me.Label16.Padding = New System.Windows.Forms.Padding(2)
        Me.Label16.Size = New System.Drawing.Size(20, 20)
        Me.Label16.TabIndex = 31
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label17.Location = New System.Drawing.Point(466, 151)
        Me.Label17.Name = "Label17"
        Me.Label17.Padding = New System.Windows.Forms.Padding(2)
        Me.Label17.Size = New System.Drawing.Size(20, 20)
        Me.Label17.TabIndex = 32
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label18.Location = New System.Drawing.Point(466, 197)
        Me.Label18.Name = "Label18"
        Me.Label18.Padding = New System.Windows.Forms.Padding(2)
        Me.Label18.Size = New System.Drawing.Size(20, 20)
        Me.Label18.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label19.Location = New System.Drawing.Point(466, 242)
        Me.Label19.Name = "Label19"
        Me.Label19.Padding = New System.Windows.Forms.Padding(2)
        Me.Label19.Size = New System.Drawing.Size(20, 20)
        Me.Label19.TabIndex = 32
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label20.Location = New System.Drawing.Point(424, 151)
        Me.Label20.Name = "Label20"
        Me.Label20.Padding = New System.Windows.Forms.Padding(2)
        Me.Label20.Size = New System.Drawing.Size(20, 20)
        Me.Label20.TabIndex = 33
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label21.Location = New System.Drawing.Point(424, 197)
        Me.Label21.Name = "Label21"
        Me.Label21.Padding = New System.Windows.Forms.Padding(2)
        Me.Label21.Size = New System.Drawing.Size(20, 20)
        Me.Label21.TabIndex = 33
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label22.Location = New System.Drawing.Point(424, 242)
        Me.Label22.Name = "Label22"
        Me.Label22.Padding = New System.Windows.Forms.Padding(2)
        Me.Label22.Size = New System.Drawing.Size(20, 20)
        Me.Label22.TabIndex = 33
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label23.Location = New System.Drawing.Point(383, 151)
        Me.Label23.Name = "Label23"
        Me.Label23.Padding = New System.Windows.Forms.Padding(2)
        Me.Label23.Size = New System.Drawing.Size(20, 20)
        Me.Label23.TabIndex = 34
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label24.Location = New System.Drawing.Point(383, 197)
        Me.Label24.Name = "Label24"
        Me.Label24.Padding = New System.Windows.Forms.Padding(2)
        Me.Label24.Size = New System.Drawing.Size(20, 20)
        Me.Label24.TabIndex = 34
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label25.Location = New System.Drawing.Point(383, 242)
        Me.Label25.Name = "Label25"
        Me.Label25.Padding = New System.Windows.Forms.Padding(2)
        Me.Label25.Size = New System.Drawing.Size(20, 20)
        Me.Label25.TabIndex = 34
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(582, 303)
        Me.ControlBox = False
        Me.Controls.Add(Me.E1)
        Me.Controls.Add(Me.D1)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.E2)
        Me.Controls.Add(Me.D2)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.E3)
        Me.Controls.Add(Me.D3)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.E4)
        Me.Controls.Add(Me.D4)
        Me.Controls.Add(Me.C4)
        Me.Controls.Add(Me.EE)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.B4)
        Me.Controls.Add(Me.B3)
        Me.Controls.Add(Me.B2)
        Me.Controls.Add(Me.B1)
        Me.Controls.Add(Me.B)
        Me.Controls.Add(Me.A4)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.A1)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.btn_c)
        Me.Controls.Add(Me.btn_x)
        Me.Controls.Add(Me.btn_r)
        Me.Controls.Add(Me.btn_e)
        Me.Controls.Add(Me.input)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Form1"
        Me.Text = "Seven Segment Display"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
    Friend WithEvents input As TextBox
    Friend WithEvents btn_e As Button

    Private Sub input_TextChanged(sender As Object, e As EventArgs) Handles input.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub btn_e_Click(sender As Object, e As EventArgs) Handles btn_e.Click
        num()
        input.Enabled = False
        btn_e.Enabled = False
        btn_c.Enabled = False
        btn_r.Visible = True
        btn_x.Visible = True

    End Sub

    Friend WithEvents btn_r As Button

    Private Sub btn_r_Click(sender As Object, e As EventArgs) Handles btn_r.Click
        A.Visible = False
        A1.Visible = False
        A2.Visible = False
        A3.Visible = False
        A4.Visible = False
        B.Visible = False
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = False
        C.Visible = False
        C1.Visible = False
        C2.Visible = False
        C3.Visible = False
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = False
        EE.Visible = False
        E1.Visible = False
        E2.Visible = False
        E3.Visible = False
        E4.Visible = False
        input.Enabled = True
        btn_e.Enabled = True
        btn_c.Enabled = True
        btn_r.Visible = False
        btn_x.Visible = False
        input.Text = ""


    End Sub

    Private Sub num()
        retry()
        If input.Text = "0" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = True
            C1.Visible = False
            C2.Visible = False
            C3.Visible = False
            C4.Visible = True
            D.Visible = True
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        ElseIf input.Text = "1" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = False
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = True
            B3.Visible = False
            B4.Visible = False
            C.Visible = False
            C1.Visible = False
            C2.Visible = True
            C3.Visible = False
            C4.Visible = False
            D.Visible = False
            D1.Visible = False
            D2.Visible = True
            D3.Visible = False
            D4.Visible = False
            EE.Visible = True
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = True
        ElseIf input.Text = "2" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = False
            C1.Visible = False
            C2.Visible = True
            C3.Visible = False
            C4.Visible = False
            D.Visible = False
            D1.Visible = True
            D2.Visible = False
            D3.Visible = False
            D4.Visible = False
            EE.Visible = True
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = True
        ElseIf input.Text = "3" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = False
            C1.Visible = False
            C2.Visible = True
            C3.Visible = True
            C4.Visible = False
            D.Visible = True
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        ElseIf input.Text = "4" Then
            A.Visible = False
            A1.Visible = False
            A2.Visible = True
            A3.Visible = False
            A4.Visible = True
            B.Visible = False
            B1.Visible = True
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = True
            C1.Visible = True
            C2.Visible = True
            C3.Visible = True
            C4.Visible = True
            D.Visible = False
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = False
            E2.Visible = False
            E3.Visible = False
            E4.Visible = True
        ElseIf input.Text = "5" Then
            A.Visible = True
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = True
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = False
            C.Visible = False
            C1.Visible = True
            C2.Visible = True
            C3.Visible = True
            C4.Visible = False
            D.Visible = False
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = True
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        ElseIf input.Text = "6" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = True
            C1.Visible = True
            C2.Visible = True
            C3.Visible = True
            C4.Visible = False
            D.Visible = True
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        ElseIf input.Text = "7" Then
            A.Visible = True
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = True
            B.Visible = False
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = False
            C1.Visible = False
            C2.Visible = False
            C3.Visible = True
            C4.Visible = False
            D.Visible = False
            D1.Visible = False
            D2.Visible = True
            D3.Visible = False
            D4.Visible = False
            EE.Visible = False
            E1.Visible = True
            E2.Visible = False
            E3.Visible = False
            E4.Visible = False
        ElseIf input.Text = "8" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = False
            C1.Visible = True
            C2.Visible = True
            C3.Visible = True
            C4.Visible = False
            D.Visible = True
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        ElseIf input.Text = "9" Then
            A.Visible = False
            A1.Visible = True
            A2.Visible = True
            A3.Visible = True
            A4.Visible = False
            B.Visible = True
            B1.Visible = False
            B2.Visible = False
            B3.Visible = False
            B4.Visible = True
            C.Visible = False
            C1.Visible = True
            C2.Visible = True
            C3.Visible = True
            C4.Visible = True
            D.Visible = False
            D1.Visible = False
            D2.Visible = False
            D3.Visible = False
            D4.Visible = True
            EE.Visible = False
            E1.Visible = True
            E2.Visible = True
            E3.Visible = True
            E4.Visible = False
        Else
            input.Text = "ERROR"
            A.Visible = True
            A1.Visible = False
            A2.Visible = False
            A3.Visible = False
            A4.Visible = True
            B.Visible = False
            B1.Visible = True
            B2.Visible = False
            B3.Visible = True
            B4.Visible = False
            C.Visible = False
            C1.Visible = False
            C2.Visible = True
            C3.Visible = False
            C4.Visible = False
            D.Visible = False
            D1.Visible = True
            D2.Visible = False
            D3.Visible = True
            D4.Visible = False
            EE.Visible = True
            E1.Visible = False
            E2.Visible = False
            E3.Visible = False
            E4.Visible = True

        End If
    End Sub
    Private Sub retry()
        A.Visible = False
        A1.Visible = False
        A2.Visible = False
        A3.Visible = False
        A4.Visible = False
        B.Visible = False
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = False
        C.Visible = False
        C1.Visible = False
        C2.Visible = False
        C3.Visible = False
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = False
        EE.Visible = False
        E1.Visible = False
        E2.Visible = False
        E3.Visible = False
        E4.Visible = False
    End Sub

    Friend WithEvents btn_x As Button

    Private Sub btn_x_Click(sender As Object, e As EventArgs) Handles btn_x.Click
        End

    End Sub

    Friend WithEvents T1 As Timer
    Friend WithEvents btn_c As Button

    Private Sub btn_c_Click(sender As Object, e As EventArgs) Handles btn_c.Click
        T1.Enabled = True
        btn_c.Enabled = False
        btn_e.Enabled = False
        input.Text = ""

    End Sub

    Private Sub T1_Tick(sender As Object, e As EventArgs) Handles T1.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = True
        C1.Visible = False
        C2.Visible = False
        C3.Visible = False
        C4.Visible = True
        D.Visible = True
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T1.Interval = 1000
        T1.Enabled = False
        T2.Enabled = True

    End Sub

    Friend WithEvents T2 As Timer
    Friend WithEvents T3 As Timer
    Friend WithEvents T4 As Timer

    Private Sub T2_Tick(sender As Object, e As EventArgs) Handles T2.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = False
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = True
        B3.Visible = False
        B4.Visible = False
        C.Visible = False
        C1.Visible = False
        C2.Visible = True
        C3.Visible = False
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = True
        D3.Visible = False
        D4.Visible = False
        EE.Visible = True
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = True
        T2.Interval = 1000
        T2.Enabled = False
        T3.Enabled = True
    End Sub

    Private Sub T3_Tick(sender As Object, e As EventArgs) Handles T3.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = False
        C1.Visible = False
        C2.Visible = True
        C3.Visible = False
        C4.Visible = False
        D.Visible = False
        D1.Visible = True
        D2.Visible = False
        D3.Visible = False
        D4.Visible = False
        EE.Visible = True
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = True
        T3.Interval = 1000
        T3.Enabled = False
        T4.Enabled = True
    End Sub

    Friend WithEvents T5 As Timer
    Friend WithEvents T6 As Timer
    Friend WithEvents T7 As Timer
    Friend WithEvents T8 As Timer
    Friend WithEvents T9 As Timer
    Friend WithEvents T10 As Timer
    Friend WithEvents T11 As Timer

    Private Sub T4_Tick(sender As Object, e As EventArgs) Handles T4.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = False
        C1.Visible = False
        C2.Visible = True
        C3.Visible = True
        C4.Visible = False
        D.Visible = True
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T4.Interval = 1000
        T4.Enabled = False
        T5.Enabled = True
    End Sub

    Private Sub T5_Tick(sender As Object, e As EventArgs) Handles T5.Tick
        A.Visible = False
        A1.Visible = False
        A2.Visible = True
        A3.Visible = False
        A4.Visible = True
        B.Visible = False
        B1.Visible = True
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = True
        C1.Visible = True
        C2.Visible = True
        C3.Visible = True
        C4.Visible = True
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = False
        E2.Visible = False
        E3.Visible = False
        E4.Visible = True
        T5.Interval = 1000
        T5.Enabled = False
        T6.Enabled = True
    End Sub

    Private Sub T6_Tick(sender As Object, e As EventArgs) Handles T6.Tick
        A.Visible = True
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = True
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = False
        C.Visible = False
        C1.Visible = True
        C2.Visible = True
        C3.Visible = True
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = True
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T6.Interval = 1000
        T6.Enabled = False
        T7.Enabled = True
    End Sub

    Private Sub T7_Tick(sender As Object, e As EventArgs) Handles T7.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = True
        C1.Visible = True
        C2.Visible = True
        C3.Visible = True
        C4.Visible = False
        D.Visible = True
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T7.Interval = 1000
        T7.Enabled = False
        T8.Enabled = True
    End Sub

    Private Sub T8_Tick(sender As Object, e As EventArgs) Handles T8.Tick
        A.Visible = True
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = True
        B.Visible = False
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = False
        C1.Visible = False
        C2.Visible = False
        C3.Visible = True
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = True
        D3.Visible = False
        D4.Visible = False
        EE.Visible = False
        E1.Visible = True
        E2.Visible = False
        E3.Visible = False
        E4.Visible = False
        T8.Interval = 1000
        T8.Enabled = False
        T9.Enabled = True
    End Sub

    Private Sub T9_Tick(sender As Object, e As EventArgs) Handles T9.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = False
        C1.Visible = True
        C2.Visible = True
        C3.Visible = True
        C4.Visible = False
        D.Visible = True
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T9.Interval = 1000
        T9.Enabled = False
        T10.Enabled = True
    End Sub

    Private Sub T10_Tick(sender As Object, e As EventArgs) Handles T10.Tick
        A.Visible = False
        A1.Visible = True
        A2.Visible = True
        A3.Visible = True
        A4.Visible = False
        B.Visible = True
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = True
        C.Visible = False
        C1.Visible = True
        C2.Visible = True
        C3.Visible = True
        C4.Visible = True
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = True
        EE.Visible = False
        E1.Visible = True
        E2.Visible = True
        E3.Visible = True
        E4.Visible = False
        T10.Interval = 1000
        T10.Enabled = False
        T11.Enabled = True
    End Sub

    Private Sub T11_Tick(sender As Object, e As EventArgs) Handles T11.Tick
        A.Visible = False
        A1.Visible = False
        A2.Visible = False
        A3.Visible = False
        A4.Visible = False
        B.Visible = False
        B1.Visible = False
        B2.Visible = False
        B3.Visible = False
        B4.Visible = False
        C.Visible = False
        C1.Visible = False
        C2.Visible = False
        C3.Visible = False
        C4.Visible = False
        D.Visible = False
        D1.Visible = False
        D2.Visible = False
        D3.Visible = False
        D4.Visible = False
        EE.Visible = False
        E1.Visible = False
        E2.Visible = False
        E3.Visible = False
        E4.Visible = False
        btn_r.Visible = True
        btn_x.Visible = True
        T11.Enabled = False
        btn_c.Enabled = False
        input.Enabled = False


    End Sub

    Friend WithEvents A As Label
    Friend WithEvents A1 As Label
    Friend WithEvents A2 As Label
    Friend WithEvents A3 As Label
    Friend WithEvents A4 As Label
    Friend WithEvents B As Label
    Friend WithEvents B1 As Label
    Friend WithEvents B2 As Label
    Friend WithEvents B3 As Label
    Friend WithEvents B4 As Label
    Friend WithEvents C As Label
    Friend WithEvents C4 As Label
    Friend WithEvents C3 As Label
    Friend WithEvents C2 As Label
    Friend WithEvents C1 As Label


    Friend WithEvents D As Label
    Friend WithEvents D4 As Label
    Friend WithEvents D3 As Label
    Friend WithEvents D2 As Label
    Friend WithEvents D1 As Label
    Friend WithEvents EE As Label
    Friend WithEvents E4 As Label
    Friend WithEvents E3 As Label
    Friend WithEvents E2 As Label
    Friend WithEvents E1 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
End Class
